#!/bin/bash
# Script to start MDM

set -e
set -x

# Set default path for cert file if no advanced path is specified
if [[ -z ${CERT_FILE} ]] && [[ -z ${PFX_FILE} ]]; then
    export CERT_FILE="/tmp/geneva_mdm/mdm-cert.pem"
fi
# Set default path for key file if no advanced path is specified
if [[ -z ${KEY_FILE} ]] && [[ -z ${PFX_FILE} ]]; then
    export KEY_FILE="/tmp/geneva_mdm/mdm-key.pem"
fi

# Parse all expected ENV variables and make sure they're good before we try and start
function parse_arguments {
    if ! [[ -z ${USE_DSMS_CERT} ]]; then
        echo "INFO: USE_DSMS_CERT is set"
        USE_DSMS_CERT_PARAM="-UseDsmsCertificate"
    fi

    # Check to make sure METRIC_ENDPOINT is set via ENV variable
    if [[ -z "${METRIC_ENDPOINT}" ]]; then
        echo "INFO: METRIC_ENDPOINT is not set, using global default"
        FRONTEND_URL_OPTION=''
    elif [ "${METRIC_ENDPOINT}" = https://az-int.metrics.nsatc.net/ ] ||
        [ "${METRIC_ENDPOINT}" = https://az-int.int.microsoftmetrics.com/ ] ||
        [ "${METRIC_ENDPOINT}" = https://global.metrics.azure.microsoft.scloud/ ] ||
        [ "${METRIC_ENDPOINT}" = https://global.metrics.azure.eaglex.ic.gov/ ]; then
        echo "INFO: METRIC_ENDPOINT is set, using ${METRIC_ENDPOINT}"
        FRONTEND_URL_OPTION="-FrontEndUrl ${METRIC_ENDPOINT}"
    elif [ "${METRIC_ENDPOINT}" = https://global.metrics.nsatc.net/ ]; then
        FRONTEND_URL_OPTION=''
        echo "WARNING: You're don't need to specify default global configuration endpoint"
        echo "Action item: Please remove METRIC_ENDPOINT=https://global.metrics.nsatc.net/ from your container configuration"
        echo "In future versions this will cause an error on startup!"
    else
        echo "ERROR: METRIC_ENDPOINT is not valid!"
        echo "ERROR: You passed in value: ${METRIC_ENDPOINT}"
        echo "The only supported values are https://az-int.metrics.nsatc.net/, https://az-int.int.microsoftmetrics.com/ and it should be only used for accessing int configuration environment"
        echo
        echo "Temporarily, for testing purposes in airgapped clouds, these can be also specified:"
        echo "* for USSec = https://global.metrics.azure.microsoft.scloud/"
        echo "* for USNat = https://global.metrics.azure.eaglex.ic.gov/"
        echo
        echo "If you've used any other option pointing to a specific stamp in the past, please remove it - it should work with default prod configuration environment"
        exit 1
    fi
}

# Parse all expected ENV variables and make sure they're good before we try and start
parse_arguments

echo "Starting MDM with the following Parameters"
echo "PFX_FILE: ${PFX_FILE}"
echo "CERT_FILE: ${CERT_FILE}"
echo "KEY_FILE: ${KEY_FILE}"
echo "METRIC_ENDPOINT: ${METRIC_ENDPOINT}"
echo "CONFIG_OVERRIDES: ${CONFIG_OVERRIDES}"
echo "CONFIG_OVERRIDES_FILE: ${CONFIG_OVERRIDES_FILE}"

# Check if transform rules dir is specified
if [[ -n "${MDM_TRANSFORM_RULES_DIR}" ]]; then
    TRANSFORM_RULES_OPTION="-TransformRulesdir ${MDM_TRANSFORM_RULES_DIR}"
    echo "TRANSFORM_RULES_OPTION: ${TRANSFORM_RULES_OPTION}"
fi

# Check if a cert path file has been defined, in which case we update the certificate authorities allowed in the node
if ! [[ -z "${CA_CERT_PATH}" ]] && [[ -f "${CA_CERT_PATH}" ]]; then
    echo "Updating CA certs"
    update-ca-certificates
fi

echo "Starting Metrics Extension"

exec /usr/sbin/MetricsExtension \
    ${FRONTEND_URL_OPTION} \
    ${TRANSFORM_RULES_OPTION} \
    -Logger Console \
    ${USE_DSMS_CERT_PARAM}
